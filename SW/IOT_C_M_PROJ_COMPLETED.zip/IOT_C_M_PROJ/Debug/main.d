main.d main.o: .././main.c .././DataTypes.h .././DRIVERS/SPI/SPI.h \
 .././DRIVERS/SPI/../../ATmega640_REGS.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h \
 .././HAL/AFE4490-INTERFACE/AFE4490.h \
 .././HAL/AFE4490-INTERFACE/../../DRIVERS/SPI/SPI.h \
 .././HAL/AFE4490-INTERFACE/../../DataTypes.h \
 .././HAL/AFE4490-INTERFACE/../../DRIVERS/EXT_INT/EXT_INT.h \
 .././HAL/AFE4490-INTERFACE/../../DRIVERS/EXT_INT/../../ATmega640_REGS.h \
 .././HAL/AFE4490-INTERFACE/AFE4490_REG.h

.././DataTypes.h:

.././DRIVERS/SPI/SPI.h:

.././DRIVERS/SPI/../../ATmega640_REGS.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h:

.././HAL/AFE4490-INTERFACE/AFE4490.h:

.././HAL/AFE4490-INTERFACE/../../DRIVERS/SPI/SPI.h:

.././HAL/AFE4490-INTERFACE/../../DataTypes.h:

.././HAL/AFE4490-INTERFACE/../../DRIVERS/EXT_INT/EXT_INT.h:

.././HAL/AFE4490-INTERFACE/../../DRIVERS/EXT_INT/../../ATmega640_REGS.h:

.././HAL/AFE4490-INTERFACE/AFE4490_REG.h:
