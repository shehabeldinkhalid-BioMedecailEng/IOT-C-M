################################################################################
# Automatically-generated file. Do not edit or delete the file
################################################################################

DRIVERS\ADC\ADC.c

DRIVERS\EEPROM\EEPROM.c

DRIVERS\EXT_INT\EXT_INT.c

DRIVERS\GPIO\GPIO.c

DRIVERS\I2C\I2C.c

DRIVERS\SPI\SPI.c

DRIVERS\TIMER\PWM\PWM.c

DRIVERS\TIMER\TIMER.c

DRIVERS\UART\UART.c

DRIVERS\WDT\WDT.c

HAL\AFE4490-INTERFACE\AFE4490.c

HAL\CONTROL\Control.c

HAL\OLED\OLED.c

HAL\OLED\OLED_Font.c

main.c

