DRIVERS/UART/UART.d DRIVERS/UART/UART.o: ../DRIVERS/UART/UART.c \
 ../DRIVERS/UART/UART.h ../DRIVERS/UART/../../DataTypes.h \
 ../DRIVERS/UART/../../ATmega640_REGS.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h

../DRIVERS/UART/UART.h:

../DRIVERS/UART/../../DataTypes.h:

../DRIVERS/UART/../../ATmega640_REGS.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h:
