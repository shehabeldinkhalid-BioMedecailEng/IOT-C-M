DRIVERS/GPIO/GPIO.d DRIVERS/GPIO/GPIO.o: ../DRIVERS/GPIO/GPIO.c \
 ../DRIVERS/GPIO/GPIO.h ../DRIVERS/GPIO/../../ATmega640_REGS.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h

../DRIVERS/GPIO/GPIO.h:

../DRIVERS/GPIO/../../ATmega640_REGS.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h:
