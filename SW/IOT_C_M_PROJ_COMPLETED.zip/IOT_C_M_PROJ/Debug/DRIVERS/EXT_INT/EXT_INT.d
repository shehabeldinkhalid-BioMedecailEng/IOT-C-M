DRIVERS/EXT_INT/EXT_INT.d DRIVERS/EXT_INT/EXT_INT.o: \
 ../DRIVERS/EXT_INT/EXT_INT.c ../DRIVERS/EXT_INT/EXT_INT.h \
 ../DRIVERS/EXT_INT/../../ATmega640_REGS.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h

../DRIVERS/EXT_INT/EXT_INT.h:

../DRIVERS/EXT_INT/../../ATmega640_REGS.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h:
