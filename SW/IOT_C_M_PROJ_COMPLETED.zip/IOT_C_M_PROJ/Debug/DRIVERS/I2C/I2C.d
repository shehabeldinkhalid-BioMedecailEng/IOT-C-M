DRIVERS/I2C/I2C.d DRIVERS/I2C/I2C.o: ../DRIVERS/I2C/I2C.c \
 ../DRIVERS/I2C/I2C.h ../DRIVERS/I2C/../../ATmega640_REGS.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h \
 ../DRIVERS/I2C/../../DataTypes.h

../DRIVERS/I2C/I2C.h:

../DRIVERS/I2C/../../ATmega640_REGS.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h:

../DRIVERS/I2C/../../DataTypes.h:
