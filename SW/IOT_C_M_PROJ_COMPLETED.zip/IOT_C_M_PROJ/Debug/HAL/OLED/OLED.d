HAL/OLED/OLED.d HAL/OLED/OLED.o: ../HAL/OLED/OLED.c \
 ../HAL/OLED/../../ATmega640_REGS.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h \
 ../HAL/OLED/../../DataTypes.h ../HAL/OLED/OLED.h \
 ../HAL/OLED/../../DRIVERS/I2C/I2C.h \
 ../HAL/OLED/../../DRIVERS/I2C/../../ATmega640_REGS.h \
 ../HAL/OLED/../../DRIVERS/I2C/../../DataTypes.h \
 ../HAL/OLED/OLED_Config.h ../HAL/OLED/OLED_Private.h \
 ../HAL/OLED/OLED_Font.h

../HAL/OLED/../../ATmega640_REGS.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h:

../HAL/OLED/../../DataTypes.h:

../HAL/OLED/OLED.h:

../HAL/OLED/../../DRIVERS/I2C/I2C.h:

../HAL/OLED/../../DRIVERS/I2C/../../ATmega640_REGS.h:

../HAL/OLED/../../DRIVERS/I2C/../../DataTypes.h:

../HAL/OLED/OLED_Config.h:

../HAL/OLED/OLED_Private.h:

../HAL/OLED/OLED_Font.h:
