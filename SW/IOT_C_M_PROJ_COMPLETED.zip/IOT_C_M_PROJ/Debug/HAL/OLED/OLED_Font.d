HAL/OLED/OLED_Font.d HAL/OLED/OLED_Font.o: ../HAL/OLED/OLED_Font.c \
 ../HAL/OLED/../../DataTypes.h ../HAL/OLED/OLED_Font.h

../HAL/OLED/../../DataTypes.h:

../HAL/OLED/OLED_Font.h:
