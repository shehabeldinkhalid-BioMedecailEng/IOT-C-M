HAL/CONTROL/Control.d HAL/CONTROL/Control.o: ../HAL/CONTROL/Control.c \
 ../HAL/CONTROL/Control.h ../HAL/CONTROL/../../DataTypes.h \
 ../HAL/CONTROL/../../ATmega640_REGS.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h

../HAL/CONTROL/Control.h:

../HAL/CONTROL/../../DataTypes.h:

../HAL/CONTROL/../../ATmega640_REGS.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h:
